package com.amb.proyecto2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Bienvenida : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bienvenida)
    }
}