package com.amb.proyecto2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var edUser: EditText = findViewById(R.id.edUser)
        var edPass: EditText = findViewById(R.id.edPass)
        var btnInput: Button = findViewById(R.id.btnIngresar)
        var btnRestart: Button = findViewById(R.id.btnResetear)

        btnRestart.setOnClickListener {
            edUser.setText("")
            edPass.setText("")
        }

        fun validarDatos(){
            val user = edUser.text
            val pass = edPass.text

            if (user.toString().isEmpty()) {
                Toast.makeText(
                    this@MainActivity, "El nombre de usuario " +
                            "no puede estar vacío ",
                    Toast.LENGTH_SHORT
                ).show()
            }
            else {
                // ir a otra pantalla
                val intent = Intent(this, Bienvenida::class.java)
                intent.putExtra("Usuario", user.toString())
                startActivity(intent)
            }
            Toast.makeText(this@MainActivity,user,Toast.LENGTH_SHORT).show()
        }

        btnInput.setOnClickListener {
            validarDatos()

        }
    }
}